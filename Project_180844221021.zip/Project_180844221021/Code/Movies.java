package com.example.anotherapplication.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Movies implements Parcelable {

    private String movieName;
    private int imageName;

    public Movies(String movieName, int imageName) {
        this.movieName = movieName;
        this.imageName = imageName;
    }

    protected Movies(Parcel in) {
        movieName = in.readString();
        imageName = in.readInt();
    }

    public static final Creator<Movies> CREATOR = new Creator<Movies>() {
        @Override
        public Movies createFromParcel(Parcel in) {
            return new Movies(in);
        }

        @Override
        public Movies[] newArray(int size) {
            return new Movies[size];
        }
    };

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public int getImageName() {
        return imageName;
    }

    public void setImageName(int imageName) {
        this.imageName = imageName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(movieName);
        dest.writeInt(imageName);
    }
}
