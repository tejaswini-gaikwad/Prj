package com.example.anotherapplication;

import android.view.View;

public interface RecyclerItemClick<T> {
    void itemClick(T t, View view);
}
