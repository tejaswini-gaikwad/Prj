package com.example.anotherapplication.detailactivity;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;

import com.example.anotherapplication.RecyclerItemClick;

public class SeatAdapter extends RecyclerView.Adapter<SeatViewHolder> {
    //make a list of image that it has seat image drawble so in view holder your view is clicked
    //u will fill that image drawable and u get that click handling on AnotherDetailActivity
    private RecyclerItemClick recyclerItemClick;

    public SeatAdapter(RecyclerItemClick recyclerItemClick) {
        this.recyclerItemClick = recyclerItemClick;
    }

    @NonNull
    @Override
    public SeatViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull SeatViewHolder seatViewHolder, int i) {

        seatViewHolder.bindData("asdas",recyclerItemClick);
    }

    @Override
    public int getItemCount() {
        //return size of your drawable image list that contain seat image
        return 0;
    }
}


class SeatViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    private RecyclerItemClick mRecyclerItemClick;


    public SeatViewHolder(@NonNull View itemView) {
        super(itemView);
        itemView.setOnClickListener(this);
    }

    public void bindData(Object object, RecyclerItemClick recyclerItemClick) {
        this.mRecyclerItemClick = recyclerItemClick;
    }


    @Override
    public void onClick(View v) {

        if (mRecyclerItemClick!=null) {
            mRecyclerItemClick.itemClick("this is temporary string now from here u send ur any kind of own data",itemView);
        }
    }
}