package com.example.anotherapplication.util;

public class NavigationHelper {

}
