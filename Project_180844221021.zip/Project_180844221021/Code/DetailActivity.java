package com.example.anotherapplication.detailactivity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.anotherapplication.R;
import com.example.anotherapplication.model.Movies;

public class DetailActivity extends AppCompatActivity {
    private TextView mMovieName;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        mMovieName = findViewById(R.id.movie_name);

        Movies movies = getIntent().getParcelableExtra("datas");
        mMovieName.setText(movies.getMovieName());
    }
}
