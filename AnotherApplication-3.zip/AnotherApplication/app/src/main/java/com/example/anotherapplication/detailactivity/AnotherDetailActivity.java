package com.example.anotherapplication.detailactivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.anotherapplication.R;

import java.util.ArrayList;

public class AnotherDetailActivity extends AppCompatActivity {

    private Spinner mlocationSpinner;
    private Spinner mTheatreSpinner;
    private Spinner mMovieSpinner;
    private RecyclerView mRecyclerView;
    private String mLocationData, mMovieData, mTheatreData;
    private Button mBookNow;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_another_detail);
        setUpUi();
        setUpList();
    }

    private void setUpUi() {
        mlocationSpinner = findViewById(R.id.place_spinner);
        mMovieSpinner = findViewById(R.id.movie_spinner);
        mTheatreSpinner = findViewById(R.id.theatre_spinner);
        mBookNow = findViewById(R.id.book_now);

    }

    private void setUpList() {
        final ArrayList<String> locationList = new ArrayList<>();
        final ArrayList<String> theatreList = new ArrayList<>();
        final ArrayList<String> movieList = new ArrayList<>();

        locationList.add("Nandurbar");
        locationList.add("Jalgaon");
        locationList.add("Dhule");

        theatreList.add("City Centre Mall");
        theatreList.add("Nandurbar Lado Mall");

        movieList.add("Uri");
        movieList.add("Moana");
        movieList.add("Spiderman");


        ArrayAdapter<String> locationListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, locationList);
        locationListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayAdapter<String> theatreListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, theatreList);
        theatreListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayAdapter<String> movieListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, movieList);
        movieListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        mlocationSpinner.setAdapter(locationListAdapter);
        mMovieSpinner.setAdapter(movieListAdapter);
        mTheatreSpinner.setAdapter(theatreListAdapter);


        mlocationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //on this metho
                mLocationData = locationList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mMovieSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mMovieData = movieList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mTheatreSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mTheatreData = theatreList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        mBookNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mLocationData != null && mMovieData != null && mTheatreData != null) {
                    Intent intent = new Intent(AnotherDetailActivity.this,
                            BookingDetailActivity.class);

                    intent.putExtra("locationData", mLocationData);
                    intent.putExtra("movieData", mMovieData);
                    intent.putExtra("theatreData", mTheatreData);

                    startActivity(intent);
                } else {
                    Toast.makeText(AnotherDetailActivity.this, "data is Invalid", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
