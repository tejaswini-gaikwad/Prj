package com.example.anotherapplication.detailactivity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import com.example.anotherapplication.R;

public class BookingDetailActivity extends AppCompatActivity {

    private TextView mPlaceDetail;
    private TextView mTheatreDetail;
    private TextView mMovieName;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_detail);
        setUpUi();
        setUpListner();

    }

    private void setUpUi() {

        String locationData = getIntent().getStringExtra("locationData");
        String movieData = getIntent().getStringExtra("movieData");
        String theatreData = getIntent().getStringExtra("theatreData");

        mMovieName = findViewById(R.id.movie_name_detail);
        mPlaceDetail = findViewById(R.id.place_name);
        mTheatreDetail = findViewById(R.id.theatre_name);


        if (locationData != null && movieData != null && theatreData != null) {
            mPlaceDetail.setText(locationData);
            mTheatreDetail.setText(theatreData);
            mMovieName.setText(movieData);
        } else {
            Toast.makeText(this, "data is null may be", Toast.LENGTH_SHORT).show();
        }
    }

    private void setUpListner() {


    }

}
