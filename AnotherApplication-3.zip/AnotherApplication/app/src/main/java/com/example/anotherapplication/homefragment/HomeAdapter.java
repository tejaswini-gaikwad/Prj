package com.example.anotherapplication.homefragment;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.anotherapplication.R;
import com.example.anotherapplication.RecyclerItemClick;
import com.example.anotherapplication.model.Movies;

import java.util.ArrayList;


public class HomeAdapter extends RecyclerView.Adapter<HomeViewHolder> {

    private RecyclerItemClick recyclerItemClick;
    private ArrayList<Movies> movies;

    public HomeAdapter(RecyclerItemClick recyclerItemClick, ArrayList<Movies> movies) {
        this.recyclerItemClick = recyclerItemClick;
        this.movies = movies;
    }

    @NonNull
    @Override
    public HomeViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.home_view_holder,viewGroup,false);
        return new HomeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HomeViewHolder homeViewHolder, int i) {
        Movies movie = movies.get(i);
        homeViewHolder.bindData(movie,recyclerItemClick);
    }

    @Override
    public int getItemCount() {
        return movies.size();
    }
}

class HomeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    private ImageView mMovieImage;
    private TextView mMovieTitle;
    private Movies movies;
    private RecyclerItemClick recyclerItemClick;

    public HomeViewHolder(@NonNull View itemView) {
        super(itemView);
        itemView.setOnClickListener(this);
        mMovieTitle = itemView.findViewById(R.id.movie_title);
        mMovieImage = itemView.findViewById(R.id.movie_image);
    }

    //this method is used for to bind data in our home_view_holder xml
    //so when your data response change or u want different xml
    //change in home_view_holder xml so u can give whatever flavour of your own xml
    //and change this model class if response change name of pojo Movie make same
    //it will less headache for you


    void bindData(Object object,RecyclerItemClick recyclerItemClick) {
        this.movies = (Movies) object;
        this.recyclerItemClick = recyclerItemClick;
        mMovieImage.setImageDrawable(itemView.getResources().getDrawable(movies.getImageName()));
        mMovieTitle.setText(movies.getMovieName());

    }


    @Override
    public void onClick(View v) {
        if (recyclerItemClick != null && movies != null) {
            recyclerItemClick.itemClick(movies,itemView);
        }
    }
}
