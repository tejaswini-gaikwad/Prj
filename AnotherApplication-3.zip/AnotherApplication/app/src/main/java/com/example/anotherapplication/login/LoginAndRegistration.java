package com.example.anotherapplication.login;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import com.example.anotherapplication.MainActivity;
import com.example.anotherapplication.R;

import java.util.Objects;


public class LoginAndRegistration extends AppCompatActivity {

    //check every view or layout is imported from android x or it will become headache to you
    private Button mBtnLogn;
    private Button mBtnSignUp;
    private EditText mUsername;
    private EditText mPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setUpUi();
    }

    private void setUpUi() {
        mUsername = findViewById(R.id.user_name);
        mPassword = findViewById(R.id.email);

        Log.d("us","username "+mUsername.getText().toString());


    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void Login(View view) {
        String pass = Objects.requireNonNull(mPassword.getText()).toString();
        if (isValid() && pass.length() > 4)
            startActivity(new Intent(LoginAndRegistration.this, MainActivity.class));
         else {
            mUsername.setError("invalid email");
            mPassword.setError("password is greater 4 character");
         }

    }

    public void Signup(View view) {
        startActivity(new Intent(this,RegistrationActivity.class));
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private boolean isValid() {
        return Objects.requireNonNull(mUsername.getText()).toString().contains("@") && mUsername.getText().toString().contains(".");
    }

}
