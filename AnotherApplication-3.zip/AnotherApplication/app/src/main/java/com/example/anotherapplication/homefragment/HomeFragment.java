package com.example.anotherapplication.homefragment;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.anotherapplication.R;
import com.example.anotherapplication.RecyclerItemClick;
import com.example.anotherapplication.detailactivity.AnotherDetailActivity;
import com.example.anotherapplication.detailactivity.DetailActivity;
import com.example.anotherapplication.login.RegistrationActivity;
import com.example.anotherapplication.model.Movies;

import java.util.ArrayList;
import java.util.Objects;


public class HomeFragment extends Fragment implements RecyclerItemClick<Movies> {

    private RecyclerView recyclerView;
    private HomeAdapter homeAdapter;
    private Button mBookbtn;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home,container,false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setUpUi(view);

    }

    private void setUpUi(View view) {
        recyclerView = view.findViewById(R.id.home_recycler_view);
        mBookbtn = view.findViewById(R.id.movie_book_now);
        homeAdapter = new HomeAdapter(this,getData());
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(),2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(homeAdapter);


        mBookbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),AnotherDetailActivity.class);
                startActivity(intent);
            }
        });
    }




    private ArrayList<Movies> getData() {

        //this method is used to give data to @{HomeAdapter} class when
        //you service is ready remove this method and make network call
        //to your database get list of data from database
        //bind it to your pojo class and perform operation

        ArrayList<Movies> list = new ArrayList<>();
        list.add(new Movies("Uri",R.drawable.uri));
        list.add(new Movies("WhyCheatIndia",R.drawable.cheatindia));
        list.add(new Movies("Simba",R.drawable.simba));
        list.add(new Movies("Marry Popens",R.drawable.marry));
        list.add(new Movies("Spiderman",R.drawable.spiderman));


        return list;

    }

    @Override
    public void itemClick(Movies movies, View view) {

        //this method is used to handle recycler item click
        //which gives moview object
        //so it depend on you to open fragment or activity on this click


        Intent intent = new Intent(getActivity(), DetailActivity.class);
        intent.putExtra("datas",movies);
        startActivity(intent);


    }


}
